import React from 'react';
import 'babel-core/polyfill.js';
import Components from './components/components.js';

React.render(

    <Components/>,
    document.getElementById('app')
);
