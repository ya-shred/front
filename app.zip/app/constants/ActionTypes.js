export const SEND_MESSAGE = 'SEND_MESSAGE';
export const ADD_MESSAGE  = 'ADD_MESSAGE';
export const ADD_USER     = 'ADD_USER';
export const REMOVE_USER  = 'REMOVE_USER';

